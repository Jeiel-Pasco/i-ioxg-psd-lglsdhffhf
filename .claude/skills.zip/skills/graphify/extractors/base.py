# DO NOT import from graphify.extract here — direction is extract.py → extractors/ only.
from __future__ import annotations

import sys
from contextvars import ContextVar
from pathlib import Path

from graphify.ids import make_id

# Ambient scan root of the extraction in flight. extract.py's
# _safe_extract_with_xaml_root sets it around every per-file extraction; the
# extractors that need the corpus boundary read it (Markdown link resolution and
# the XAML C# project-root clamp). It lives here rather than in graphify.extract
# so those extractors read it in the correct import direction (extract.py ->
# extractors/, never back), per MIGRATION.md invariant #4 — the old
# function-local `import graphify.extract` + getattr(..., None) was a package ->
# parent dependency that also failed silently if the module global were renamed
# (#3666). None outside extract().
#
# A ContextVar rather than a module global: extraction runs concurrently
# (ThreadPoolExecutor in tests, process pools in production), and a plain
# global lets overlapping save/restore pairs interleave — the second call
# saves the first one's root and restores it last, leaving the ambient root
# set after extract() returns (#4602). ContextVar gives every thread (and
# async task) its own value, so save/restore pairs nest correctly without a
# lock.
#
# Semantic note: because the value is context-local, a root set on one
# thread is NOT visible to worker threads spawned mid-extraction. Every
# real call path sets and reads the root inside the same pool worker
# (_safe_extract_with_xaml_root runs inside the worker; the scan root also
# travels to workers as an explicit `root` parameter, not via this
# global), so no production path crosses the boundary. If a future
# extractor needs cross-thread visibility, propagate explicitly with
# contextvars.copy_context() at the dispatch site.
_ACTIVE_SCAN_ROOT: "ContextVar[Path | None]" = ContextVar(
    "_ACTIVE_SCAN_ROOT", default=None
)


def set_active_scan_root(root: "Path | None") -> "Path | None":
    """Set the in-flight scan root, returning the previous value so the caller
    can restore it — extraction nests (a XAML shard re-enters extract())."""
    previous = _ACTIVE_SCAN_ROOT.get()
    _ACTIVE_SCAN_ROOT.set(root)
    return previous


def active_scan_root() -> "Path | None":
    """The scan root of the extraction in flight, or None outside extract().

    A direct ``extract_markdown()`` / ``extract_xaml()`` call (no surrounding
    ``extract()``) sees None and the root-dependent behavior stays off."""
    return _ACTIVE_SCAN_ROOT.get()

# Language built-in globals that AST may classify as call targets when used as
# constructors or coercion functions (e.g. String(x), Number(x), Boolean(x)).
# Without this filter they become god-nodes accumulating spurious edges from
# every call site. Filter applied at same-file and cross-file resolution.
# See issue #726.
_LANGUAGE_BUILTIN_GLOBALS: frozenset[str] = frozenset({
    # JavaScript / TypeScript ECMAScript built-ins
    "String", "Number", "Boolean", "Object", "Array", "Symbol", "BigInt",
    "Date", "RegExp", "Error", "TypeError", "RangeError", "SyntaxError",
    "ReferenceError", "EvalError", "URIError",
    "Promise", "Map", "Set", "WeakMap", "WeakSet", "JSON", "Math",
    "Reflect", "Proxy", "Intl",
    "parseInt", "parseFloat", "isNaN", "isFinite",
    "encodeURIComponent", "decodeURIComponent", "encodeURI", "decodeURI",
    # Browser / Node common globals
    "URL", "URLSearchParams", "FormData", "Blob", "File",
    "Headers", "Request", "Response", "AbortController", "AbortSignal",
    "TextEncoder", "TextDecoder", "console",
    # Python built-in callables
    "str", "int", "float", "bool", "list", "dict", "set", "tuple", "bytes",
    "len", "range", "enumerate", "zip", "map", "filter", "sum", "min", "max",
    "print", "open", "isinstance", "type", "super", "sorted", "reversed",
    "any", "all", "abs", "round", "next", "iter", "hash", "id", "repr",
    "callable", "getattr", "setattr", "hasattr", "delattr", "vars", "dir",
    # Swift standard library / Foundation / SwiftUI (#2147). Value-type
    # initializers (Data(x), Int(x), UUID()) and protocol conformance targets
    # appear from virtually every file of a Swift codebase, exactly like the
    # ECMAScript constructors above. String/Date/URL/Error are already listed.
    "Int", "Int8", "Int16", "Int32", "Int64",
    "UInt", "UInt8", "UInt16", "UInt32", "UInt64",
    "Double", "Float", "Bool", "Character",
    "Sendable", "Codable", "Decodable", "Encodable", "Equatable", "Hashable",
    "Identifiable", "Comparable", "CaseIterable", "RawRepresentable",
    "CustomStringConvertible", "CustomDebugStringConvertible", "AnyObject",
    "LocalizedError",
    "Data", "UUID", "Decimal", "Calendar", "Locale", "TimeZone", "Bundle",
    "IndexPath", "IndexSet", "NotificationCenter", "UserDefaults",
    "FileManager", "URLSession", "URLRequest", "URLComponents",
    "JSONDecoder", "JSONEncoder", "DateFormatter", "NumberFormatter",
    "ISO8601DateFormatter",
    "NSObject", "NSString", "NSError", "NSLock", "NSAttributedString",
    "DispatchQueue", "DispatchGroup", "OperationQueue", "RunLoop",
    "View", "Color", "Font",
})

# Python's own builtin namespace, deliberately kept separate from
# ``_LANGUAGE_BUILTIN_GLOBALS``. That set is consulted at extraction time for a
# bare call, where dropping the raw call is correct for a true builtin but also
# throws away the evidence needed to resolve a legitimate imported class that
# merely shares a builtin's name (#4989). This set is only consulted after a
# cross-file candidate has been found, and only to require a direct import
# binding before accepting it: in Python a bare name resolves to the builtin
# unless the module binds it itself, so `raise NotImplementedError` in a file
# that never imports anything must not link to a package class named
# ``NotImplementedError``. Fixed rather than derived from ``dir(builtins)`` so
# extraction stays deterministic across interpreter versions.
_PYTHON_BUILTIN_NAMES: frozenset[str] = frozenset({
    "ArithmeticError", "AssertionError", "AttributeError", "BaseException",
    "BaseExceptionGroup", "BlockingIOError", "BrokenPipeError", "BufferError",
    "BytesWarning", "ChildProcessError", "ConnectionAbortedError", "ConnectionError",
    "ConnectionRefusedError", "ConnectionResetError", "DeprecationWarning", "EOFError",
    "Ellipsis", "EncodingWarning", "EnvironmentError", "Exception", "ExceptionGroup",
    "False", "FileExistsError", "FileNotFoundError", "FloatingPointError",
    "FutureWarning", "GeneratorExit", "IOError", "ImportError", "ImportWarning",
    "IndentationError", "IndexError", "InterruptedError", "IsADirectoryError",
    "KeyError", "KeyboardInterrupt", "LookupError", "MemoryError",
    "ModuleNotFoundError", "NameError", "None", "NotADirectoryError", "NotImplemented",
    "NotImplementedError", "OSError", "OverflowError", "PendingDeprecationWarning",
    "PermissionError", "ProcessLookupError", "RecursionError", "ReferenceError",
    "ResourceWarning", "RuntimeError", "RuntimeWarning", "StopAsyncIteration",
    "StopIteration", "SyntaxError", "SyntaxWarning", "SystemError", "SystemExit",
    "TabError", "TimeoutError", "True", "TypeError", "UnboundLocalError",
    "UnicodeDecodeError", "UnicodeEncodeError", "UnicodeError", "UnicodeTranslateError",
    "UnicodeWarning", "UserWarning", "ValueError", "Warning", "ZeroDivisionError",
    "abs", "aiter", "all", "anext", "any", "ascii", "bin", "bool", "breakpoint",
    "bytearray", "bytes", "callable", "chr", "classmethod", "compile", "complex",
    "copyright", "credits", "delattr", "dict", "dir", "divmod", "enumerate", "eval",
    "exec", "exit", "filter", "float", "format", "frozenset", "getattr", "globals",
    "hasattr", "hash", "help", "hex", "id", "input", "int", "isinstance", "issubclass",
    "iter", "len", "license", "list", "locals", "map", "max", "memoryview", "min",
    "next", "object", "oct", "open", "ord", "pow", "print", "property", "quit", "range",
    "repr", "reversed", "round", "set", "setattr", "slice", "sorted", "staticmethod",
    "str", "sum", "super", "tuple", "type", "vars", "zip",
})


def _make_id(*parts: str) -> str:
    return make_id(*parts)


def _file_stem(path: Path) -> str:
    """Stem used as the node-ID prefix for a file and its symbols.

    The full path (extension dropped) is preserved as path segments; ``make_id``
    later collapses the separators to underscores. Using every segment — not just
    the immediate parent dir (#1504) — means same-named files in different
    directories get distinct IDs instead of colliding into one
    last-writer-wins node:

        docs/v1/api/README.md -> docs/v1/api/README -> docs_v1_api_readme
        docs/v2/api/README.md -> docs/v2/api/README -> docs_v2_api_readme

    Top-level files keep a bare stem (``setup.py`` -> ``setup``). When passed an
    absolute path the whole path is encoded; the extract() id-remap post-pass
    re-derives the canonical repo-relative form from ``source_file`` so the on-disk
    location can't leak into the persisted IDs (#502).

    Returns "" for a path with no name (``Path('.')`` — a source_file that equals
    the scan root, so it has no per-file stem). Guarding here keeps
    ``path.with_suffix("")`` from raising ``ValueError: '.' has an empty name`` and
    protects every caller, not just ``_semantic_id_remap`` (#1618)."""
    if not path.name:
        return ""
    return path.with_suffix("").as_posix()


def _read_text(node, source: bytes) -> str:
    return source[node.start_byte:node.end_byte].decode("utf-8", errors="replace")


_UTF32_BOMS = (b"\xff\xfe\x00\x00", b"\x00\x00\xfe\xff")
_UTF16_BOMS = (b"\xff\xfe", b"\xfe\xff")
# Fixed, not the host locale: extraction must give the same graph on every
# machine (CONTRIBUTING: deterministic extraction).
_SOURCE_FALLBACK_ENCODINGS = ("cp1252", "latin-1")
_warned_source_encodings: set[str] = set()


def _read_source_bytes(path: Path, *, warn: bool = True) -> bytes:
    """Read a source file as the UTF-8 bytes tree-sitter parses.

    tree-sitter treats its input as UTF-8. Raw bytes in another encoding were
    parsed as-is: a UTF-16 file (interleaved NUL bytes) produced no nodes at
    all, and a Windows-1252 identifier was cut at its first non-UTF-8 byte
    (``CaféOrder`` came out as ``Order``) — both silently.

    Valid UTF-8, with or without a BOM, is returned byte-for-byte, so node ids,
    byte offsets and cache keys for those files are unchanged. A UTF-16 or
    UTF-32 file with a BOM is decoded exactly and re-encoded as UTF-8. Anything
    else is decoded as cp1252, then latin-1 (which cannot fail), so names come
    out whole; line numbers are unchanged in every case. ``warn`` names the file
    once per process on that last, guessed path — pass ``warn=False`` from
    secondary passes that re-read a file the extractor already read.
    """
    raw = path.read_bytes()
    if raw.isascii():
        return raw
    try:
        raw.decode("utf-8")
        return raw
    except UnicodeDecodeError:
        pass
    for boms, encoding in ((_UTF32_BOMS, "utf-32"), (_UTF16_BOMS, "utf-16")):
        if raw.startswith(boms):
            try:
                return raw.decode(encoding).encode("utf-8")
            except UnicodeDecodeError:
                continue  # FF FE 00 00 is also UTF-16-LE: BOM + U+0000
    for encoding in _SOURCE_FALLBACK_ENCODINGS:
        try:
            text = raw.decode(encoding)
        except UnicodeDecodeError:
            continue
        key = str(path)
        if warn and key not in _warned_source_encodings:
            _warned_source_encodings.add(key)
            print(
                f"[graphify] WARNING: {path} is not valid UTF-8; read it as {encoding}. "
                "Re-save it as UTF-8 if names in the graph look wrong.",
                file=sys.stderr,
            )
        return text.encode("utf-8")
    return raw  # unreachable: latin-1 decodes every byte


def _read_source_text(path: Path, *, warn: bool = True) -> str:
    """``_read_source_bytes`` as text, for extractors that work on ``str``.

    Matches ``path.read_text(encoding="utf-8")`` exactly for every valid UTF-8
    file, including its universal-newline translation (``\\r\\n`` and a lone
    ``\\r`` both become ``\\n``) and a kept BOM, so regex extractors see the same
    text they always did.
    """
    text = _read_source_bytes(path, warn=warn).decode("utf-8")
    return text.replace("\r\n", "\n").replace("\r", "\n")
